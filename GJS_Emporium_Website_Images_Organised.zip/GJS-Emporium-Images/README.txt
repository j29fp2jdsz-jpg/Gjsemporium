GJ'S EMPORIUM — ORGANISED IMAGE UPLOAD

Upload the contents of GJS-Emporium-Images/ to your GitHub repository.
Keep the folders intact. Do not upload the ZIP as a single image: extract it first.

IMPORTANT: This is an image library, NOT a stock import.
- Only the items in available-now/ are grouped with current sale listings. Confirm status with Garry.
- All past-work/ images are examples of completed work, NOT newly available.
- review-before-publishing/ contains images with embedded price text or uncertain identity.
- Some pieces may already appear on the website; these are original/source photos or extra angles.
- No images have been retouched, resized, or cropped.
- This archive does not automatically change the website code.

See image-manifest.csv for the original-to-new filename mapping.
